const supportedFields = {
	text: "Text",
	richtext: "Rich Text",
	number: "Number",
	date: "Date",
	media: "Media",
	boolean: "Boolean",
	relationship: "Relationship (Beta)",
	// multipleChoice: "Multiple Choice",
};

export default supportedFields;
