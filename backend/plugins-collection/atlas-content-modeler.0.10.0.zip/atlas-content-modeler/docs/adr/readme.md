[Architectural decision records](https://adr.github.io/) live here to record the thought process behind significant architectural choices.
